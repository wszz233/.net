namespace OnlineShopAPI.Dtos;

public record class ProductSummaryDto(
    int Id, 
    string Name, 
    string ProductType, 
    decimal Price,
    int Stock, 
    string PictureUrl);