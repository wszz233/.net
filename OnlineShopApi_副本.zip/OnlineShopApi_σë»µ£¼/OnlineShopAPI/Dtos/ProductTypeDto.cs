namespace OnlineShopAPI.Dtos;

public record class ProductTypeDto(int Id,string Name);
