namespace OnlineShopAPI.Dtos;

public record class ProductDetailsDto(
    int Id, 
    string Name, 
    int ProductTypeId, 
    decimal Price,
    int Stock, 
    string PictureUrl);