using System;

using System.ComponentModel.DataAnnotations;
using OnlineShopAPI.Dtos;
using OnlineShopAPI.Entities;

public record class OrderDto(
    int Id,
    DateTime OrderDate,


    string UserId,


    OrderStatus Status,


    decimal TotalAmount,


    string ShippingAddress,

    string ShippingPhone,


    List<OrderItemDto> Items
);