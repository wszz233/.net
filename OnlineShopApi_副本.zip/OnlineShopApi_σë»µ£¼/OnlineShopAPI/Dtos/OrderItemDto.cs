using OnlineShopAPI.Entities;
using System.ComponentModel.DataAnnotations;

namespace OnlineShopAPI.Dtos;


public record class OrderItemDto(
    [Required]
    int ProductId,  // 修正：使用 int 类型的 ProductId

    [Required]
    [StringLength(50)]
    string ProductName,

    [Required]
    [Range(1, 10000)]
    int Quantity,

    [Required]
    [Range(0, 1000000)]
    decimal Price,

    string? PictureUrl
);