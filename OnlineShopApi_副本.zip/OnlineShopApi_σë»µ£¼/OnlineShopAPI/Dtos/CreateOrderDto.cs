using System.ComponentModel.DataAnnotations;

namespace OnlineShopAPI.Dtos;

public record class CreateOrderDto(
    [Required]
    [StringLength(50)]
    string UserId,

    [Required]
    [StringLength(200)]
    string ShippingAddress,

    [Required]
    [StringLength(20)]
    string ShippingPhone,

    [Required]
    List<CreateOrderItemDto> Items
);