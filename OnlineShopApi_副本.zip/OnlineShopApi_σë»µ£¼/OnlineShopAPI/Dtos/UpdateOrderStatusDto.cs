namespace OnlineShopAPI.Dtos;
using OnlineShopAPI.Entities;
public record class UpdateOrderStatusDto(
    OrderStatus Status,
    string ShippingAddress,

    string ShippingPhone,
        string UserId);
