using System.ComponentModel.DataAnnotations;

namespace OnlineShopAPI.Dtos;

public record class UpdateProdcutDto(
    [Required][StringLength(50)]string Name, 
    int ProductTypeId,
    [Range(1,1000)]decimal Price,
    [Range(1,10000)]int Stock, 
    string PictureUrl
);
