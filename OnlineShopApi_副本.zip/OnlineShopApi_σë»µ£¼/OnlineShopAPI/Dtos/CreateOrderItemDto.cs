using System.ComponentModel.DataAnnotations;

namespace OnlineShopAPI.Dtos;

 public record class CreateOrderItemDto
 {
     [Required]
     public int ProductId { get; set; }

     [Required]
     [Range(1, 10000)]
     public int Quantity { get; set; } // 改为 set
 }
