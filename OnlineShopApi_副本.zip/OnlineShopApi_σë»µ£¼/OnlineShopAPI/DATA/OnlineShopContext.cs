using System;
using OnlineShopAPI.Entities;
using Microsoft.EntityFrameworkCore;

namespace OnlineShopAPI.DATA;

public class OnlineShopContext(DbContextOptions<OnlineShopContext>options)
:DbContext(options)
{
public DbSet<Product> Products=>Set<Product>();
public DbSet<ProductType> ProductTypes => Set<ProductType>();
public DbSet<Order> Orders => Set<Order>();// 添加 Order
public DbSet<OrderItem> OrderItems=>Set<OrderItem>();// 添加 OrderItem

protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ProductType>().HasData(
            new ProductType { Id = 1, Name = "香烟" },
            new ProductType { Id = 2, Name = "槟榔" },
            new ProductType { Id = 3, Name = "零食" },
            new ProductType { Id = 4, Name = "饮料" },
            new ProductType { Id = 5, Name = "生活用品" }
            );
     

    // ... (关系配置) ...
     modelBuilder.Entity<OrderItem>()
        .HasOne(oi => oi.Order)
        .WithMany(o => o.Items)
        .HasForeignKey(oi => oi.OrderId);

    modelBuilder.Entity<OrderItem>()
        .HasOne(oi => oi.Product)
        .WithMany()
        .HasForeignKey(oi => oi.ProductId);
     modelBuilder.Entity<Order>()
        .Property(o => o.Status)
        .HasConversion<string>();

    }

}