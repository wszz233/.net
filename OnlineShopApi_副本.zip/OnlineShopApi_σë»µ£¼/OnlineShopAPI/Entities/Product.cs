using System;

namespace OnlineShopAPI.Entities;

public class Product
{
    public int Id { get; set; } 
    public required string Name { get; set; }    
    public int ProductTypeId { get; set; }
    public ProductType? ProductType { get; set; }  
    public decimal Price { get; set; }
    public int Stock { get; set; }
    public required string PictureUrl { get; set; }

}
