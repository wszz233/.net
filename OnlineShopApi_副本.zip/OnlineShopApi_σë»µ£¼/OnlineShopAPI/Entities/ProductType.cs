using System;

namespace OnlineShopAPI.Entities;

public class ProductType
{
    public int Id { get; set; }
    public required string Name { get; set; }
}
