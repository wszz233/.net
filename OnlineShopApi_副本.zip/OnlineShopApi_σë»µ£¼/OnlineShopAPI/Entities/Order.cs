using System;
using System.ComponentModel.DataAnnotations;
using OnlineShopAPI.Entities;
namespace OnlineShopAPI.Entities;

public class Order
{
    public int Id { get; set; }
    public DateTime OrderDate { get; set; }

    public required string UserId { get; set; }

    public OrderStatus Status { get; set; } 


    public decimal TotalAmount { get; set; }



    public required string ShippingAddress { get; set; }


    public required string ShippingPhone { get; set; }

    public List<OrderItem> Items { get; init; } = [];

    // ...

    // 添加一个方法来更新状态
    public void UpdateStatus(OrderStatus newStatus)
    {
        Status = newStatus;
    }
}


