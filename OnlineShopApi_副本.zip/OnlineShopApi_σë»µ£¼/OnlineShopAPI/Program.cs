using System.Text.Json.Serialization;
using OnlineShopAPI.DATA;
using OnlineShopAPI.Endpoints;


var builder = WebApplication.CreateBuilder(args);
builder.Services.AddHttpClient();
var connstring=builder.Configuration.GetConnectionString("OnlineShop");
builder.Services.AddSqlite<OnlineShopContext>(connstring);
// Add services to the container.
builder.Services.AddControllers();
builder.Services.Configure<Microsoft.AspNetCore.Http.Json.JsonOptions>(options =>
{
    options.SerializerOptions.Converters.Add(new JsonStringEnumConverter());
});
builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenLocalhost(5204); // HTTP
    options.ListenLocalhost(7296, listenOptions =>
    {
        listenOptions.UseHttps(); // HTTPS
    });
});
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigin",
        builder => builder.WithOrigins("http://localhost:5173")
                          .AllowAnyHeader()
                          .AllowAnyMethod());
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
// Use CORS policy
app.UseCors("AllowSpecificOrigin");


app.UseAuthorization();



app.MapControllers();
app.UseHttpsRedirection();
app.UseRouting();
app.UseAuthorization();

app.MapControllers();


app.MapProductsEndpoints(); 
app.MapProductTypesEndpoints();
app.MapOrdersEndpoints();
app.MapLoginEndpoint();

await app.MigrateDbAsync();

app.Run();



