using System;
using OnlineShopAPI.Dtos;
using OnlineShopAPI.Entities;

namespace OnlineShopAPI.Mapping;

public static class ProductTypeMapping
{
    public static ProductTypeDto ToDto(this ProductType productType)
    {
        return new ProductTypeDto(productType.Id, productType.Name);
        
    }
}
