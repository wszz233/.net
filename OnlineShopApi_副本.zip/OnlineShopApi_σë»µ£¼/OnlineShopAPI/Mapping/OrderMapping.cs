using System;
using OnlineShopAPI.Dtos;
using OnlineShopAPI.Entities;
using OnlineShopAPI.Mapping;

namespace OnlineShopAPI.Mapping;

public static class OrderMapping
{
         public static OrderDto ToOrderDto(this Order order)
    {
          //手动处理OrderDto, 避免AutoMapper可能出现的循环引用问题.
        var orderDto = new OrderDto
        (
            order.Id,
            order.OrderDate,
            order.UserId,
            order.Status,
            order.TotalAmount,
            order.ShippingAddress,  // 设置地址和电话
            order.ShippingPhone,      // 设置地址和电话
            order.Items.Select(oi=> oi.ToOrderItemDto()).ToList()
        );
        return orderDto;
    }

    // CreateOrderDto -> Order  (注意：这里不处理 Items，Items 在 Controller 中处理)
    public static Order ToEntity(this CreateOrderDto createOrderDto)
    {
        return new Order
        {
            OrderDate = DateTime.Now, // 创建订单时设置时间
            UserId = createOrderDto.UserId,
            Status = OrderStatus.Paid, // 默认状态
            ShippingAddress = createOrderDto.ShippingAddress,
            ShippingPhone = createOrderDto.ShippingPhone,
            // TotalAmount 和 Items 在 Controller 中计算和设置
        };
    }
    
}
