using System;
using OnlineShopAPI.Dtos;
using OnlineShopAPI.Entities;
using OnlineShopAPI.DATA;
using System.Formats.Asn1;

namespace OnlineShopAPI.Mapping;

public static class OrderItemMapping

{
    public static OrderItem ToEntity(this CreateOrderItemDto createItemDto, int orderId) // 没有 async, 返回 OrderItem
    {
        return new OrderItem
        {
            OrderId = orderId,
            ProductId = createItemDto.ProductId,
            Quantity = createItemDto.Quantity,
            // Price, Product, Order 在 Controller/Endpoint 中设置
        };
    }   
    public static OrderItemDto ToOrderItemDto(this OrderItem orderItem)
    {
        return new OrderItemDto(
            orderItem.ProductId,
            orderItem.Product!.Name,
            orderItem.Quantity,
            orderItem.Price,
            orderItem.Product.PictureUrl
        );
    }


    
}

