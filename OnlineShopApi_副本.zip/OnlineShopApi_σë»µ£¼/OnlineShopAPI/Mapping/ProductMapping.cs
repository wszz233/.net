using System;
using Microsoft.AspNetCore.Http.HttpResults;
using OnlineShopAPI.Dtos;
using OnlineShopAPI.Entities;

namespace OnlineShopAPI.Mapping;

public static class ProductMapping
{
    public static Product ToEntity(this CreatProductDto product)
    {
        return new Product()
                {
                    Name=product.Name,
                    ProductTypeId=product.ProductTypeId,
                    Price=product.Price,
                    Stock=product.Stock,
                    PictureUrl=product.PictureUrl
                };
    }
    public static Product ToEntity(this UpdateProdcutDto product,int id)
    {
        return new Product()
                {
                    Id=id,
                    Name=product.Name,
                    ProductTypeId=product.ProductTypeId,
                    Price=product.Price,
                    Stock=product.Stock,
                    PictureUrl=product.PictureUrl
                };
    }
    public static ProductSummaryDto ToProductSummaryDto(this Product product)
    {
        return new(
            product.Id,
            product.Name,
            product.ProductType!.Name,
            product.Price,
            product.Stock,
            product.PictureUrl
        );
    }


    public static ProductDetailsDto ToProductDetailsDto(this Product product)
    {
        return new(
            product.Id,
            product.Name,
            product.ProductTypeId,
            product.Price,
            product.Stock,
            product.PictureUrl
        );
    }
}
