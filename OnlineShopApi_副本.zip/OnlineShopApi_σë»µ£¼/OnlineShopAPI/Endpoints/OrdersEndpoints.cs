using System;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using OnlineShopAPI.DATA;
using OnlineShopAPI.Dtos;
using OnlineShopAPI.Entities;
using OnlineShopAPI.Mapping;

namespace OnlineShopAPI.Endpoints;

public static class OrdersEndpoints
{
    const string GetOrderEndpointName = "GetOrder";
    const string GetOrdersEndpointName = "GetOrders";

    public static RouteGroupBuilder MapOrdersEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("api/orders")
                    .WithParameterValidation();

        // POST /api/orders (创建订单)
        group.MapPost("/", async (CreateOrderDto createOrderDto, OnlineShopContext dbContext) =>
        {
            using var transaction = await dbContext.Database.BeginTransactionAsync();
            try
            {
                var order = createOrderDto.ToEntity();

                // 合并重复的商品项
                var mergedItems = new Dictionary<int, CreateOrderItemDto>();
                foreach (var itemDto in createOrderDto.Items)
                {
                    if (mergedItems.TryGetValue(itemDto.ProductId, out var existingItem))
                    {
                        existingItem.Quantity += itemDto.Quantity;
                    }
                    else
                    {
                        mergedItems.Add(itemDto.ProductId, itemDto);
                    }
                }

                foreach (var itemDto in mergedItems.Values)
                {
                    //  同步调用 ToEntity
                    var orderItem = itemDto.ToEntity(order.Id);

                    var product = await dbContext.Products.FindAsync(itemDto.ProductId);
                    if (product == null)
                    {
                        return Results.BadRequest(new { message = $"找不到商品 (ID: {itemDto.ProductId})" });
                    }

                    if (product.Stock < orderItem.Quantity)
                    {
                        return Results.BadRequest(new { message = $"商品 '{product.Name}' (ID: {product.Id}) 库存不足" });
                    }

                    product.Stock -= orderItem.Quantity;

                    orderItem.Price = product.Price;
                    orderItem.Product = product;
                    orderItem.Order = order;

                    order.Items.Add(orderItem);
                    order.TotalAmount += orderItem.Price * orderItem.Quantity;
                }

                dbContext.Orders.Add(order);
                await dbContext.SaveChangesAsync();
                await transaction.CommitAsync();

                // 重新加载 Order，包含 Items 和 Products
                var createdOrder = await dbContext.Orders
                    .Include(o => o.Items)
                        .ThenInclude(oi => oi.Product)
                    .AsNoTracking()
                    .FirstOrDefaultAsync(o => o.Id == order.Id);

                if (createdOrder == null)
                {
                    return Results.Problem("创建订单失败，未找到创建的订单。", statusCode: 500);
                }

                // 将 Order 转换为 OrderDto
                var orderDto = createdOrder.ToOrderDto(); // 使用 ToOrderDto

                return Results.CreatedAtRoute(GetOrderEndpointName, new { id = orderDto.Id }, orderDto); // 返回 OrderDto
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return Results.Problem(detail: $"创建订单失败: {ex.Message}", statusCode: 500);
            }
        })
        .WithName("CreateOrder");

        // GET /api/orders/{id} (获取订单详情)
        group.MapGet("/{id}", async (int id, OnlineShopContext dbContext) =>
        {
            var order = await dbContext.Orders
                .Include(o => o.Items)
                    .ThenInclude(oi => oi.Product)
                .AsNoTracking()
                .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null)
            {
                return Results.NotFound();
            }

            return Results.Ok(order.ToOrderDto()); // 返回 OrderDto
        })
        .WithName(GetOrderEndpointName);

        // GET /api/orders (获取所有订单)
        group.MapGet("/", async (OnlineShopContext dbContext) =>
        {
            var orders = await dbContext.Orders
                .Include(o => o.Items)
                    .ThenInclude(oi => oi.Product)
                .AsNoTracking()
                .ToListAsync();

            // 将 Order 列表转换为 OrderDto 列表
            var orderDtos = orders.Select(o => o.ToOrderDto()).ToList();

            return Results.Ok(orderDtos); // 返回 OrderDto 列表
        })
        .WithName(GetOrdersEndpointName);
         //更新订单状态
        group.MapPatch("/{id}/status", async (int id, UpdateOrderStatusDto updateOrderStatusDto, OnlineShopContext dbContext) =>
        {
            var existingOrder = await dbContext.Orders.FindAsync(id);
            if (existingOrder == null)
            {
                return Results.NotFound();
            }

            // 直接更新订单状态 (或使用 UpdateStatus 方法)
            existingOrder.UpdateStatus(updateOrderStatusDto.Status);
            //existingOrder.Status = updateOrderStatusDto.Status; //或者直接赋值

            await dbContext.SaveChangesAsync();

            return Results.NoContent(); // 返回 204 No Content
        });
        // GET /api/orders/by-user/{openId} (根据OpenID获取订单)
        group.MapGet("/by-user/{openId}", async (string openId, OnlineShopContext dbContext) =>
        {
            var orders = await dbContext.Orders
                .Where(o => o.UserId == openId) // 假设 UserId 存储的是 OpenID
                .Include(o => o.Items)
                    .ThenInclude(oi => oi.Product)
                .AsNoTracking()
                .ToListAsync();

            if (orders == null || !orders.Any())
            {
                return Results.NotFound();
            }

            var orderDtos = orders.Select(o => o.ToOrderDto()).ToList();

            return Results.Ok(orderDtos);
        })
        .WithName("GetOrdersByUser");
        return group;
    }
   
}