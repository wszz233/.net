using System;
using Microsoft.EntityFrameworkCore;
using OnlineShopAPI.DATA;
using OnlineShopAPI.Entities;
using OnlineShopAPI.Mapping;

namespace OnlineShopAPI.Endpoints;

public static class ProductTypeEndpoints
{
    public static RouteGroupBuilder MapProductTypesEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("productTypes");

        group.MapGet("/",async (OnlineShopContext dbContext)=>
        await dbContext.ProductTypes
                        .Select(productType=>productType.ToDto())
                        .AsNoTracking()
                        .ToListAsync()
                        );
        return group;
    }
}
