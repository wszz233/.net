using System;
using Microsoft.EntityFrameworkCore;
using OnlineShopAPI.DATA;
using OnlineShopAPI.Dtos;
using OnlineShopAPI.Entities;
using OnlineShopAPI.Mapping;

using System.Net;
namespace OnlineShopAPI.Endpoints;

public static class ProductsEndpoints
{
    const string GetProductEndpointName = "GetProduct";

   
    public static RouteGroupBuilder MapProductsEndpoints(this WebApplication app)
    {
        var group=app.MapGroup("products")
                    .WithParameterValidation();
        //GET /products
        group.MapGet("/", async(OnlineShopContext dbContext) => 
        await dbContext.Products
                .Include(products=>products.ProductType)
                .Select(product=>product.ToProductSummaryDto())
                .AsNoTracking()
                .ToListAsync());
        //GET /products/1
        group.MapGet("/{id}", async(int id,OnlineShopContext dbContext) => {
            Product? product =await dbContext.Products.FindAsync(id);
            return product is not null ? Results.Ok(product.ToProductDetailsDto()) : Results.NotFound();})
            .WithName(GetProductEndpointName);
        //POST /products
        group.MapPost("/",async(CreatProductDto newProduct,OnlineShopContext dbContext)=>
        {
            Product product=newProduct.ToEntity();
            
            dbContext.Products.Add(product);
            await dbContext.SaveChangesAsync();

            

            return Results.CreatedAtRoute(
                GetProductEndpointName, 
                new {id=product.Id}, 
                product.ToProductDetailsDto());

        });
        //PUT /products
        group.MapPut("/{id}",async(int id,UpdateProdcutDto updatedProduct,OnlineShopContext dbContext)=>
        {
            
        var existingProduct=await dbContext.Products.FindAsync(id);
            
            if(existingProduct is null)
            {
                return Results.NotFound();
            }
            
            dbContext.Entry(existingProduct)
            .CurrentValues.
            SetValues(updatedProduct.ToEntity(id));
            await dbContext.SaveChangesAsync();

            return Results.NoContent();
        });
        //DELETE /products  
        group.MapDelete("/{id}",async(int id,OnlineShopContext dbContext)=>{
            await dbContext.Products.Where(product=>product.Id==id)
                            .ExecuteDeleteAsync();  
            return Results.NoContent(); 
        });
                return group; 
    }
}
