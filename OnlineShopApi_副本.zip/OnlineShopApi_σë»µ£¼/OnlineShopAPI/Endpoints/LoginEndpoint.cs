using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace OnlineShopAPI.Endpoints
{
    public static class LoginEndpoint
    {
        public static WebApplication MapLoginEndpoint(this WebApplication app)
        {
            app.MapPost("/api/login", async (HttpClient httpClient, [FromBody] WeChatLoginRequest request) =>
            {
                if (string.IsNullOrEmpty(request.Code))
                {
                    return Results.BadRequest(new { error = "Code is required" });
                }

                var appId = "wx56b91e2397b95543"; // 直接写入你的 appId
                var appSecret = "a77a05a9b1c01f059902bec8618a2b68"; // 直接写入你的 appSecret
                var url = $"https://api.weixin.qq.com/sns/jscode2session?appid={appId}&secret={appSecret}&js_code={request.Code}&grant_type=authorization_code";

                var response = await httpClient.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return Results.Problem(detail: "Failed to get response from WeChat API", statusCode: (int)response.StatusCode);
                }

                var responseContent = await response.Content.ReadAsStringAsync();
                var jsonResponse = JsonDocument.Parse(responseContent);

                var openId = jsonResponse.RootElement.GetProperty("openid").GetString();
                var sessionKey = jsonResponse.RootElement.GetProperty("session_key").GetString();

                if (string.IsNullOrEmpty(openId) || string.IsNullOrEmpty(sessionKey))
                {
                    return Results.BadRequest(new { error = "Invalid response from WeChat API" });
                }

                return Results.Ok(new { openId, sessionKey });
            });

            return app;
        }
    }

    public class WeChatLoginRequest
    {
        public string? Code { get; set; }
    }
}